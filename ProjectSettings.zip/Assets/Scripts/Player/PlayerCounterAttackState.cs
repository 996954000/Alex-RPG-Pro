using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCounterAttackState : PlayerState
{
    private bool successFlag;
    public PlayerCounterAttackState(PlayerStateMachine _stateMachine, Player _player, string _animBoolName) : base(_stateMachine, _player, _animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
        successFlag = false;
        /* ���� enemy �Ƿ��� CBCAWindow (CanBeCounterAttackWindow)
         * ������Χ���Ϊ�ڶ��ι����ķ�Χ */
        Collider2D[] collider2Ds = Physics2D.OverlapCircleAll(player.groundAttackTrans.position, player.groundAttackRadius[1]);
        foreach (var hit in collider2Ds)
        {
            /* �������д��ڿɱ���ѣ�ĵ�λ������ѣ�䣬�����ŷ����ɹ����� */
            if (hit.GetComponent<Enemy>() != null && hit.GetComponent<Enemy>().CanBeCounterAttackWindowCheck())
            {
                hit.GetComponent<Enemy>().BeStunned();
                successFlag = true;
            }
        }

        if (successFlag)
            player.animator.SetBool("SuccessCounterAttack", true);
    }

    public override void Exit()
    {
        base.Exit();
        player.animator.SetBool("SuccessCounterAttack", false);
    }

    public override void Update()
    {
        base.Update();
        if (!successFlag && stateTimer > 0.3f)
            stateMachine.ChangeState(player.idleState);
        else
        {
            if (animationTrigger)
                stateMachine.ChangeState(player.idleState);
        }

    }
}
