using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGroundedState : PlayerState
{
    public PlayerGroundedState(PlayerStateMachine _stateMachine, Player _player, string _animBoolName) : base(_stateMachine, _player, _animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();
        /* ��Ծ */
        if (Input.GetKeyDown(KeyCode.Space))
        {
            stateMachine.ChangeState(player.jumpState);
        }

        /* ����״̬ */
        if (player.rigidbody2D.velocity.y < 0 && !isGrounded)
            stateMachine.ChangeState(player.airState);

        /* ���� */
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            stateMachine.ChangeState(player.primaryAttackState);
        }

        /* ���� */
        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            stateMachine.ChangeState(player.counterAttackState);
        }

        /* ��׼ */
        /* 
           ���ӱ�־λ�����Ƿ��н����������н����� */
        /* ������ CD �� �Ƿ��н��ļ�� */
        if (Input.GetKeyDown(KeyCode.Z) && player.skill.skill_throwSword.CanUseSkill())
        {
            if (player.flyingSword == null)
                stateMachine.ChangeState(player.aimState);
            else
            {
                player.skill.skill_throwSword.UseSkill();
            }
        }
        if (player.catchSword)
            stateMachine.ChangeState(player.catchSwordState);
    }
}
