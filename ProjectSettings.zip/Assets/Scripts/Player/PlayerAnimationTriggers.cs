using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimationTriggers : MonoBehaviour {
    public Player player;
    private Enemy enemy;
    public void Awake()
    {
        player = GetComponentInParent<Player>();
    }

    public void AnimationFinishedTrigger() => player.AnimationFinishedTrigger();

    public void DamageTrigger()
    {
        Collider2D[] collider2Ds = Physics2D.OverlapCircleAll(player.groundAttackTrans.position, player.groundAttackRadius[player.groundAttackPhase]);
        foreach(var hit in collider2Ds)
        {
            if (hit.GetComponent<Enemy>() != null)
            {
                enemy = hit.GetComponent<Enemy>();
                /* ��ͬ�Ĺ����׶ζ�Ӧ��ͬ������Ч�� */
                //enemy.DamagedByAttackPhase(player.primaryAttackState.GetGroundAttackPhase());
                
                
                /* enemy��ʧ����ֵ��������Ϊplayer */
                hit.GetComponent<Enemy>().entityStat.DoDamage(player);
            }
        }
    }
}
