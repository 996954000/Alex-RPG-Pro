using UnityEngine;
public class PlayerStat : EntityStat
{
    public override void DoDamage(Entity _attacker)
    {
        // �˺������ж�
        if (IsAvoidAttack())
            return;
        else
        {
            // �ܻ�Ч��
            GetComponent<Player>().DamagedByAttackPhase(0);

            base.DoDamage(_attacker);
        }
    }

    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        base.Update();
    }


}
