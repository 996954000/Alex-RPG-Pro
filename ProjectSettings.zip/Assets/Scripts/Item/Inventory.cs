
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Unity.VisualScripting;
using static UnityEditor.Progress;
using static UnityEngine.Rendering.DebugUI;

public class Inventory : MonoBehaviour 
{
    public static Inventory instance;

    /* �ֿ� */
    public List<InventoryItem> inventoryItems;
    public Dictionary<ItemData, InventoryItem> inventoryDictionary;

    /* ��Ʒ���� */
    public List<InventoryItem> stashItems;
    public Dictionary<ItemData, InventoryItem> stashDictionary;

    /* װ���б� */
    public List<InventoryItem> equipmentItems;
    public Dictionary<ItemData_Equipment, InventoryItem> equipmentDictionary;

    public UI_ItemSlot[] uI_InventorySlots;
    public UI_ItemSlot[] uI_StashSlots;
    public UI_EquipmentItemSlot[] uI_EquipSlots;

    /* ��Ʒ���ͨ��Ԥ�Ƽ� */
    [SerializeField] private GameObject itemSlotPrefab;

    /* װ���������ڵ� */
    [SerializeField] private Transform itemSlotsParents;
    
    /* ���ϱ������ڵ� */
    [SerializeField] private Transform stashSlotsParents;

    /* װ�������ڵ� */
    [SerializeField] private Transform equipmentSlotsParents;

    /* Slots���� */
    [SerializeField] private int slotsCount;
    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(instance.gameObject);
    }
    public void Start()
    {
        inventoryItems = new List<InventoryItem>();
        inventoryDictionary = new Dictionary<ItemData, InventoryItem>();

        stashItems = new List<InventoryItem>();
        stashDictionary = new Dictionary<ItemData, InventoryItem>();

        equipmentItems = new List<InventoryItem>();
        equipmentDictionary = new Dictionary<ItemData_Equipment, InventoryItem>();

        /* ��Ϸ�й̶����úõ�װ����Slots */
        uI_EquipSlots = equipmentSlotsParents.GetComponentsInChildren<UI_EquipmentItemSlot>();
        
        /* ��ʼ��Slots */
        iniSlots();

        /* ��ȡ���ڵ���Slots */
        uI_InventorySlots = itemSlotsParents.GetComponentsInChildren<UI_ItemSlot>();
        uI_StashSlots = stashSlotsParents.GetComponentsInChildren<UI_ItemSlot>();
    }

    private void iniSlots()
    {
        GameObject newItemSlot = new GameObject();
        /* ����һ�������ı���Slots */
        for (int i = 0; i < slotsCount; i++)
        {
            newItemSlot = GameObject.Instantiate(itemSlotPrefab);
            newItemSlot.transform.parent = itemSlotsParents.transform;
            newItemSlot = GameObject.Instantiate(itemSlotPrefab);
            newItemSlot.transform.parent = stashSlotsParents.transform;
        }
    }

    /* ����������Ʒ */
    public void AddItem(ItemData _item)
    {
        if (_item != null)
        {
            if (_item.category == Category.Equipment)
            {
                AddInventoryItem(_item);
            }
            else if (_item.category == Category.Material)
            {
                AddStashItem(_item);
            }
        }
    }
    /* ���Ӳ���  AddItem*/
    private void AddStashItem(ItemData _item)
    {
        if (stashDictionary.TryGetValue(_item, out InventoryItem value))
        {
            value.AddStack();
        }
        else
        {
            InventoryItem newItem = new InventoryItem(_item);
            stashItems.Add(newItem);
            stashDictionary.Add(_item, newItem);
            newItem.AddStack();
        }
        UpdateStashItemSlots();
    }
    /* ����װ��  AddItem*/
    private void AddInventoryItem(ItemData _item)
    {
        if (inventoryDictionary.TryGetValue(_item, out InventoryItem value))
        {
            value.AddStack();
        }
        else
        {
            InventoryItem newItem = new InventoryItem(_item);
            inventoryItems.Add(newItem);
            inventoryDictionary.Add(_item, newItem);
            newItem.AddStack();
        }
        UpdateInventoryItemSlots();
    }
    /* �����Ƴ���Ʒ  */
    public void RemoveItem(ItemData _item)
    {
        if (_item != null)
        {
            if (_item.category == Category.Equipment)
            {
                RemoveInventoryItem(_item);
            }
            else if (_item.category == Category.Material)
            {
                RemoveStashItem(_item);
            }
        }
    }
    /* װ�������Ƴ�װ�� RemoveItem*/
    public void RemoveInventoryItem(ItemData _item)
    {
        
        if (inventoryDictionary.TryGetValue(_item, out InventoryItem value))
        {
            if (value.stackSize > 1)
                value.RemoveStack();
            else
            {
                inventoryItems.Remove(value);
                inventoryDictionary.Remove(_item);
            }
        }
        UpdateInventoryItemSlots();
    }
    /* ���ϱ����Ƴ����� RemoveItem*/
    public void RemoveStashItem(ItemData _item)
    {

        if (stashDictionary.TryGetValue(_item, out InventoryItem value))
        {
            if (value.stackSize > 1)
                value.RemoveStack();
            else
            {
                stashItems.Remove(value);
                stashDictionary.Remove(_item);
            }
        }
        UpdateStashItemSlots();
    }

    /* װ����Ʒ */
    public void EquipItem(ItemData _item)
    {
        ItemData_Equipment equipingItem = _item as ItemData_Equipment;
        
        /*  */
        if (inventoryDictionary.TryGetValue(_item, out InventoryItem value))
        {
            if (equipmentItems.Count > 0)
            {
                Debug.Log("EquipItem-Get>0");
                InventoryItem tempItem = null;
                /* ������װ���� */
                foreach (InventoryItem item in equipmentItems)
                {
                    /* ����װ����Ҫװ����װ�����ͣ�������滻 */
                    ItemData_Equipment equipedItem = item.itemData as ItemData_Equipment;
                    if (equipedItem.equipmentType == equipingItem.equipmentType)
                    {
                        // ��¼�����������滻
                        tempItem = item;
                    }
                }/* ������Ҫ�����滻��װ�� */
                if (tempItem != null)
                {
                    /* װ�������Ƴ���װ�� ���ڱ��������Ӹ�װ��*/
                    equipmentItems.Remove(tempItem);
                    AddInventoryItem(tempItem.itemData);
                }
                
            }
            /* װ��������װ�� */
            equipmentItems.Add(value);
            /* װ�������Ƴ�װ�� */
            RemoveInventoryItem(value.itemData);
        }
        /* ����װ������Ϣ */
        UpdateEquipmentItemSlots();
    }

    /* ������װ������Ӧ���޸��� */
    public void AddEquipItem(ItemData _item)
    {
        
    }
    /* �Ƴ�װ����Ӧ���޸��� */

    /* ����װ������ */
    public void UpdateInventoryItemSlots() {
        if (inventoryItems.Count != 0 && uI_InventorySlots.Length != 0) {
            for (int i = 0; i < uI_InventorySlots.Length; i++)
            {
                if (i < inventoryItems.Count)
                    uI_InventorySlots[i].UpdateItemSlot(inventoryItems[i]);
                else
                    uI_InventorySlots[i].UpdateItemSlot(null);
            }
        }
    }

    /* ������Ʒ�ֿ� */
    public void UpdateStashItemSlots()
    {
        uI_StashSlots = stashSlotsParents.GetComponentsInChildren<UI_ItemSlot>();

        for (int i = 0; i < stashItems.Count; i++)
        {
            uI_StashSlots[i].UpdateItemSlot(stashItems[i]);
        }
    }

    /* ����װ���� */
    public void UpdateEquipmentItemSlots()
    {
        Debug.Log("UpdateEquipmentItemSlots");
        foreach (InventoryItem inventoryItem in equipmentItems)
        {
            ItemData_Equipment itemData_Equipment = inventoryItem.itemData as ItemData_Equipment;
            foreach (UI_EquipmentItemSlot slot in uI_EquipSlots)
            {
                /* �Ժ����� */
                if (slot.equipmentType == itemData_Equipment.equipmentType)
                {
                    Debug.Log("equipmentType right");
                    slot.itemData = itemData_Equipment;
                    slot.UpdateItemSlot(inventoryItem);
                }
                else
                {
                    Debug.Log("equipmentType false");
                    slot.itemData = null;
                }
            }
        }
    }
    

}
