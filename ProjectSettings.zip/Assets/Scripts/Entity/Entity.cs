using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity : MonoBehaviour
{
    #region Components
    public Animator animator { get; private set; }
    public Rigidbody2D rigidbody2D { get; private set; }
    public EntityFX entityFX { get; private set; }
    public EntityStat entityStat { get; private set; }
    #endregion

    #region States

    #endregion

    #region Parameters
    [Header("Ground Check Info")]
    [SerializeField] protected Transform groundCheckTrans;
    [SerializeField] protected Vector2 checkDir;
    [SerializeField] protected float groundCheckDistance;
    [SerializeField] protected LayerMask whatIsGround;

    [Header("Wall Check Info")]
    [SerializeField] protected Transform wallCheckTrans;
    [SerializeField] protected Vector2 wallCheckDir;
    [SerializeField] protected float wallCheckDistance;
    [SerializeField] protected LayerMask whatIsWall;

    [Header("Flip Info")]
    public Vector2 faceDir;
    [SerializeField] public bool faceRight;

    [Header("Damaged")]
    [SerializeField] public Vector2 knockbackForce;
    [SerializeField] protected float underAttackDuration;
    public int underAttackPhase;
    public bool underAttack;

    [Header("Gen Param")]
    [SerializeField] public float moveSpeed;
    private float oriMoveSpeed;
    #endregion
    protected virtual void Awake()
    {
        animator = GetComponentInChildren<Animator>();
        rigidbody2D = GetComponent<Rigidbody2D>();
        entityFX = GetComponent<EntityFX>();
        entityStat = GetComponent<EntityStat>();

        if (faceRight)
            faceDir = new Vector2(1.0f, 0.0f);
        else
            faceDir = new Vector2(-1.0f, 0.0f);

    }
    protected virtual void Start()
    {
        underAttack = false;
        oriMoveSpeed = moveSpeed;
    }
    protected virtual void Update()
    {
        wallCheckDir = faceDir;
    }
    /* ��ת���� */
    public virtual void FlipFix()
    {
        if (faceRight && rigidbody2D.velocity.x < 0 || !faceRight && rigidbody2D.velocity.x > 0)
            FlipCharacter();
    }
    public virtual void FlipCharacter()
    {
        faceRight = !faceRight;
        faceDir = -faceDir;
        gameObject.transform.localScale = new Vector3(-1.0f * gameObject.transform.localScale.x,
            gameObject.transform.localScale.y,
            gameObject.transform.localScale.z);
    }
    /* �ӵؼ�� */
    public virtual bool GroundedCheck()
    {
        return Physics2D.Raycast(groundCheckTrans.transform.position,
            checkDir.normalized,
            groundCheckDistance,
            whatIsGround);
    }
    /* ǽ���� */
    public virtual bool WallCheck()
    {
        return Physics2D.Raycast(wallCheckTrans.transform.position,
            wallCheckDir.normalized,
            wallCheckDistance,
            whatIsWall);
    }
    /* ���ƹ��߷��� */
    protected virtual void OnDrawGizmos()
    {
        Gizmos.DrawLine(groundCheckTrans.transform.position,
            new Vector2(groundCheckTrans.transform.position.x + groundCheckDistance * checkDir.normalized.x,
            groundCheckTrans.transform.position.y + groundCheckDistance * checkDir.normalized.y));

        Gizmos.DrawLine(wallCheckTrans.transform.position,
            new Vector2(wallCheckTrans.transform.position.x + wallCheckDistance * wallCheckDir.normalized.x,
            wallCheckTrans.transform.position.y + wallCheckDistance * wallCheckDir.normalized.y));
    }
    /* ���ø����ٶ� */
    public virtual void SetVelocity(float x, float y)
    {
        /* �����ڻ���״̬����������ٶ�����
         * ����ʹ��һ���ܵķ��������ٶȵĺô����������� */
        if (underAttack)
            return;

        rigidbody2D.velocity = new Vector2(x, y);
    }
    /* �������� animator �еĲ��� */
    public virtual void SetAnimXYVelocity(float xVelocity, float yVelocity)
    {
        animator.SetFloat("xAbsVelocity", Mathf.Abs(xVelocity));
        animator.SetFloat("yVelocity", yVelocity);
    }
    public virtual void DamagedByAttackPhase(int attackPhase)
    {
        Debug.Log(gameObject.name + "was damaged");

        /* ���� ������ ����� attackPhase ���� �ܻ��� ��underAttackPhase */
        underAttackPhase = attackPhase;
        /* ��֡���� enemy ���ܻ�״̬��״̬��ʹ�� */
        if (!underAttack)
            StartCoroutine(UnderAttackCoroutien());
        /* ������ʱ���ⷴ�� */
        StartCoroutine(entityFX.FlashFXCoroutine());
    }
    protected virtual IEnumerator UnderAttackCoroutien()
    {
        underAttack = true;
        yield return new WaitForSeconds(.05f);
        underAttack = false;
    }

    // ��deathTrigger���ã�����������������Ϻ�����gameObject
    public virtual void Death()
    {
        StartCoroutine(DestroyAfter(3.0f));
    }
    private IEnumerator DestroyAfter(float time)
    {
        yield return new WaitForSeconds(time);
        Destroy(gameObject);
    }

    // �ƶ��ٶȼ���
    public void MultiMoveSpeed(float multi)
    {
        if (multi == 1.0f)
            moveSpeed = oriMoveSpeed;
        else
            moveSpeed = moveSpeed * multi;
    }
}
