using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SwordType
{
    baseSword,
    BounceSword,
    PierceSword,
    SpinSword
}
public class Skill_ThrowSword : Skill
{
    [SerializeField] private SwordType type;

    [Header("Prefab")]
    [SerializeField] private GameObject swordPrefab;

    [Header("Rigidbody")]
    [SerializeField] private float swordGravity;
    [SerializeField] private Vector2 swordVelocity;

    [Header("Force & Speed")]
    [SerializeField] private float returnSpeed;

    [Header("Dots")]
    [SerializeField] private int dotNum;
    [SerializeField] private GameObject dotPrefab;
    [SerializeField] private float dotGap;

    [Header("Bouncy Info")]
    [SerializeField] private float bouncyRadius;
    [SerializeField] private int maxBouncyTimes;
    [SerializeField] private float bouncySwordGravity;
    [SerializeField] private Vector2 bouncySwordVelocity;

    [Header("Pierce Info")]
    [SerializeField] private int maxPierceTimes;
    [SerializeField] private float pierceSwordGravity;
    [SerializeField] private Vector2 pierceSwordVelocity;

    [Header("Spin Info")]
    [SerializeField] private float spinSwordGravity;
    [SerializeField] private Vector2 spinSwordVelocity;
    [SerializeField] private float maxSpinTime;
    [SerializeField] private float startSpinDistance;

    private GameObject[] dots;
    [SerializeField] private Transform dotsParent;
    private Vector2 aimDir;
    private bool isReturning;

    Skill_Sword_Controller controller;

    public override bool CanUseSkill()
    {
        /* �򵥵�CD��� */
        if (IsCooldownComplete())
            return true;
        else
        {
            if (!IsCooldownComplete())
                Debug.Log("Skill: " + skillName + " is CoolDowning ");
            
            return false;
        }
    }

    public override void SkillAction()
    {
        base.SkillAction();
        if ( player.flyingSword == null)
        {
            /* ����ʵ�� */
            GameObject newSword = GameObject.Instantiate(swordPrefab);
            switch (type)
            {
                case SwordType.BounceSword:
                    newSword.GetComponent<Skill_Sword_Controller>().SetUpBounce(true, bouncyRadius, maxBouncyTimes);
                    swordGravity = bouncySwordGravity;
                    swordVelocity = bouncySwordVelocity;
                    break;
                case SwordType.PierceSword:
                    newSword.GetComponent<Skill_Sword_Controller>().SetUpPierce(true, maxPierceTimes);
                    swordGravity = pierceSwordGravity;
                    swordVelocity = pierceSwordVelocity;
                    break;
                case SwordType.SpinSword:
                    newSword.GetComponent<Skill_Sword_Controller>().SetUpSpin(true, maxSpinTime, startSpinDistance, player.transform.position);
                    swordGravity = spinSwordGravity;
                    swordVelocity = spinSwordVelocity;
                    break;
            }

            // ͨ������
            newSword.GetComponent<Skill_Sword_Controller>().SetUpSword(player.gameObject,
                    swordGravity, swordVelocity, aimDir, isReturning, returnSpeed);


            /* �Ǽǽ� */
            player.AssignedSword(newSword);
        } else
            ReturnSword();
    }



    public override void UseSkill()
    {
        base.UseSkill();
    }

    /* ���ع�һ����׼���� */
    public Vector2 AimDirection()
    {
        /* ��ʼ�� */
        Vector2 startPos = player.transform.position;
        /* �����׼ */
        Vector2 aimPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        return new Vector2(aimPos.x - startPos.x, aimPos.y - startPos.y).normalized;
    }

    /* ���� dots ʵ�� */
    public GameObject[] GenDots()
    {
        dots = new GameObject[dotNum];
        for (int i = 0; i < dotNum; i++)
        {
            /* ����ʵ�������� ��������  */
            dots[i] = GameObject.Instantiate(dotPrefab, player.transform.position, Quaternion.identity, dotsParent);
            dots[i].SetActive(false);
        }
        return dots;
    }

    /* ���� dot �� index ���� dots
     * ����ļ�����ʵ���ǽ�ʱ������滻Ϊ dot �� index ����
     * �ߺ�ʵ���˶��켣��һ�£���֪��Ϊɶ */
    public void DotsPostion()
    {
        switch (type)
        {
            case SwordType.BounceSword:
                swordGravity = bouncySwordGravity;
                swordVelocity = bouncySwordVelocity;
                break;
            case SwordType.PierceSword:
                swordGravity = pierceSwordGravity;
                swordVelocity = pierceSwordVelocity;
                break;
        }

        for (int t = 0; t < dotNum; t++)
        {
            float finalT = t * dotGap;
            dots[t].transform.localPosition = new Vector2(aimDir.x * swordVelocity.x * finalT,
                (0.5f * Physics2D.gravity.y * swordGravity * finalT * finalT) + (aimDir.y * swordVelocity.y * finalT));
            dots[t].SetActive(true);
        }
        dotsParent.gameObject.SetActive(true);
    }

    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        base.Update();
        aimDir = AimDirection();
        /* dots ��λ���� player ͬ������������ player �ķ�ת */
        dotsParent.transform.position = player.transform.position;
    }

    protected override void Awake()
    {
        base.Awake();
    }

    private void ReturnSword()
    {
        player.flyingSword.GetComponent<Skill_Sword_Controller>().ReturnSword();
    }
}
