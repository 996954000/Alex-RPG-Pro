using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Skill : MonoBehaviour
{
    [Header("Managers")]
    protected Player player;

    [Header("Skill Message")]
    [SerializeField] protected string skillName;

    [Header("CoolDown")]
    [SerializeField] protected float coolDownTime;
    protected float currentCoolDownTime;

    [Header("Skill State")]
    /* ��Ǽ��ܿ���״̬�����г�Ĭ��״̬��ʹ�ô����� */
    protected bool skillCanUse;

    protected virtual void Update()
    {
        if (currentCoolDownTime > 0)
            currentCoolDownTime -= Time.deltaTime;
        else
            currentCoolDownTime = 0;
    }
    protected virtual void Start()
    {
        player = PlayerManager.instance.player;
    }
    protected virtual void OnDestroy()
    {
        
    }
    public bool IsCooldownComplete()
    {
        return currentCoolDownTime == 0 ? true : false;
    }

    /* ������Ϊ���� */
    public virtual bool CanUseSkill()
    {
        /* �򵥵�CD��� */
        if (IsCooldownComplete())
            return true;
        else
        {
            Debug.Log("Skill: " +  skillName + " is CoolDowning ");
            return false;
        }
    }
    /* ʹ�ü��� */
    public virtual void UseSkill()
    {
        if (CanUseSkill()) {
            /* ���� */
            SkillAction();

            /* ���¼���CD */
            currentCoolDownTime = coolDownTime;
        }

    }

    /* ����ļ����߼� */
    public virtual void SkillAction() { 
    
    }

    protected virtual void Awake()
    {
        
    }
}
