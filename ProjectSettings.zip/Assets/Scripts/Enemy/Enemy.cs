using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : Entity
{
    #region Parameter
    [Header("Detection Info")]
    [SerializeField] protected Transform detectionTrans;
    [SerializeField] protected Vector2 detectionDir;
    [SerializeField] public float detectionDistance;
    [SerializeField] protected LayerMask whatIsPlayer;

    [Header("Attack Info")]
    [SerializeField] public float attackRange;
    [SerializeField] public Transform attackTrans;
    [SerializeField] public float attackRadius;

    [SerializeField] public bool canBeCounterAttackedWindow;
    [SerializeField] public float beStunnedDuration;
    public bool beStunned;

    [Header("move Info")]
    // [SerializeField] public float moveSpeed;
    private float originalSpeed;
    #endregion
    #region Components
    protected EnemyStateMeachine stateMeachine;
    [SerializeField] protected GameObject canBeCAImage;
    #endregion

    public bool tempGrounded;
    protected override void Awake()
    {
        base.Awake();
        stateMeachine = new EnemyStateMeachine();

        underAttack = false;

        canBeCAImage.SetActive(false);
        canBeCounterAttackedWindow = false;
        originalSpeed = moveSpeed;
    }

    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        base.Update();
        stateMeachine.currentState.Update();
        tempGrounded = GroundedCheck();
        /* Ѱ�з�������Է���ʼ�ձ���һ�� */
        detectionDir = faceDir;


        /* ������־�� window ʼ�ձ���һ��
         * ���������ܿ϶���Ͱɣ�Ӧ���и��õķ��� */
        canBeCAImage.SetActive(canBeCounterAttackedWindow);

    }

    /* Ѱ���Լ���Χ���� �о�����û���Բ��Ѱ�� */
    protected override void OnDrawGizmos()
    {
        base.OnDrawGizmos();
        /* ׷����Χ */
        Gizmos.color = Color.green;
        Gizmos.DrawLine(detectionTrans.transform.position,
            new Vector2(detectionTrans.transform.position.x + detectionDistance * detectionDir.normalized.x,
            detectionTrans.transform.position.y + detectionDistance * detectionDir.normalized.y));

        /* ���ƹ�����Χ��ֱ�ߣ�
         * ����ǿ�ʼִ�й��������ļ����� */
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(transform.position,
            new Vector2(transform.position.x + attackRange * faceDir.x,
            transform.position.y));

        /* �����˺���Χ��Բ�Σ�
         * ����ǹ���������������˺��ķ�Χ*/
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackTrans.position, attackRadius);
    }

    public bool PlayerDetection()
    {
        return Physics2D.Raycast(detectionTrans.transform.position,
            detectionDir.normalized,
            detectionDistance,
            whatIsPlayer);
    }

    public override void DamagedByAttackPhase(int attackPhase)
    {
        base.DamagedByAttackPhase(attackPhase);
    }

    public void AnimationFinished() => stateMeachine.currentState.AnimationFinished();

    /* ������� */
    public bool CanBeCounterAttackWindowCheck() => canBeCounterAttackedWindow;

    public void OpenCounterAttackWindow()
    {
        canBeCounterAttackedWindow = true;
        //canBeCAImage.SetActive(true);
    }

    public void CloseCounterAttackWindow()
    {
        canBeCounterAttackedWindow = false;
        //canBeCAImage.SetActive(false);
    }

    /* ��������״̬��飬��ʱ�رջ��δ���
     * ���»���״̬*/
    public virtual void BeStunned()
    {
        if (beStunned)
        {
            Debug.Log("BESTUNNED" + beStunned);
            canBeCounterAttackedWindow = false;
            return;
        }
        else
            beStunned = true;
    }


}
