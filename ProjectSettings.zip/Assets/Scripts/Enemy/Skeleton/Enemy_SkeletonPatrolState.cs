using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_SkeletonPatrolState : Enemy_SkeletonState
{
    /* Ѳ��״̬���� Walk �� Idle �ĸ��࣬��������״̬�¿�תΪ����׷��״̬ */
    public Enemy_SkeletonPatrolState(Enemy baseEnemy, EnemyStateMeachine stateMeachine, string animBoolName, Enemy_Skeleton _enemy) : base(baseEnemy, stateMeachine, animBoolName, _enemy)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void Update()
    {
        base.Update();
        if (enemy_Skeleton.PlayerDetection())
            stateMeachine.changeState(enemy_Skeleton.reactState);
    }
}
