using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Skeleton : Enemy
{
    /* ��Ϊ Enemy ���Ϊ�ܶ��ֵ��ˣ�����ÿ�����˵Ĳ������ͣ�״̬����һ��������д�˸��м��� */
    #region States
    public Enemy_SkeletonIdleState idleState { get; private set; }
    public Enemy_SkeletonWalkState walkState { get; private set; }
    /* ��������״̬ */
    public Enemy_SkeletonReactState reactState { get; private set; }
    /* Ѱ��״̬ */
    public Enemy_SkeletonBattleState battleState { get; private set; }
    /* ����״̬ */
    public Enemy_SkeletonAttackState attackState { get; private set; }
    /* �ܻ�״̬ */
    public Enemy_SkeletonUnderAttackState underAttackState { get; private set; }
    /* ��ѣ״̬ */
    public Enemy_SkeletonStunState stunState { get; private set; }
    /* ����״̬ */
    public Enemy_SkeletonDeathState deathState { get; private set; }
    #endregion
    #region Parameters
    [Header("Move Info")]
    /* ׷��״̬�ƶ��ٶȳ˷�ϵ�� */
    [SerializeField] public float battleSpeedMultiplier;
    #endregion
    protected override void Awake()
    {
        base.Awake();
        
        idleState = new Enemy_SkeletonIdleState(this, stateMeachine, "Idle", this);
        walkState = new Enemy_SkeletonWalkState(this, stateMeachine, "Walk", this);
        battleState = new Enemy_SkeletonBattleState(this, stateMeachine, "Battle", this);
        reactState = new Enemy_SkeletonReactState(this, stateMeachine, "React", this);
        attackState = new Enemy_SkeletonAttackState(this, stateMeachine, "Attack", this);
        underAttackState = new Enemy_SkeletonUnderAttackState(this, stateMeachine, "UnderAttack", this);
        stunState = new Enemy_SkeletonStunState(this, stateMeachine, "Stun", this);
        deathState = new Enemy_SkeletonDeathState(this, stateMeachine, "Death", this);
    }

    protected override void Start()
    {
        base.Start();

        stateMeachine.initState(idleState);
    }

    protected override void Update()
    {
        base.Update();
        /* ������״̬ */
        if (beStunned)
            stateMeachine.changeState(stunState);
    }

    protected override void OnDrawGizmos()
    {
        base.OnDrawGizmos();
    }

    public override void BeStunned()
    {
        base.BeStunned();
    }
}
