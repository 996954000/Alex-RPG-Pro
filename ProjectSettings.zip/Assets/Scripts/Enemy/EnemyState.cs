using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class EnemyState
{
    protected Enemy baseEnemy;
    protected EnemyStateMeachine stateMeachine;
    protected string animBoolName;

    protected float stateTimer;
    protected bool animationTrigger;
    public EnemyState(Enemy baseEnemy, EnemyStateMeachine stateMeachine, string animBoolName)
    {
        this.baseEnemy = baseEnemy;
        this.stateMeachine = stateMeachine;
        this.animBoolName = animBoolName;
    }

    public virtual void Enter()
    {
        stateTimer = 0;
        animationTrigger = false;
        baseEnemy.animator.SetBool(animBoolName, true);
    }

    public virtual void Exit()
    {
        baseEnemy.animator.SetBool(animBoolName, false);
    }

    public virtual void Update()
    {
        stateTimer += Time.deltaTime;
    }

    /* ������ Player �ڶ�������ʱ���ö�Ӧ״̬�� trigger �� true
     * trigger = true ��������������ϣ����Խ�����һ��״̬��*/
    public void AnimationFinished()
    {
        animationTrigger = true;
    }
}
